package com.example.test2b;


public class event_details {

    private int eventid;

    private String eventname;

    private String eventdate;

    private String location;

    public event_details(int eventid, String eventname, String eventdate, String location) {
        this. eventid= eventid;
        this.eventname = eventname;
        this.eventdate = eventdate;
        this.location = location;

    }

    public int getEventid() {
        return eventid;
    }

    public void setEventid(int eventid) {
        this.eventid = eventid;
    }

    public String getEventname() {
        return eventname;
    }

    public void setEventname(String eventname) {
        this.eventname = eventname;
    }

    public String getEventdate() {
        return eventdate;
    }

    public void setEventdate(String eventdate) {
        this.eventdate = eventdate;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }