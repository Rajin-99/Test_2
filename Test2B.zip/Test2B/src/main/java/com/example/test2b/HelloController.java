package com.example.test2b;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;
import java.sql.*;

public class HelloController implements Initializable {
    public TableView<event_details> eventtable;
    public TableColumn <event_details,String>eventdate;
    public TableColumn <event_details,String>location;
    public TableColumn <event_details,String>eventname;
    public TableColumn <event_details,Integer>eventid;
    public TextField seventid;
    public TextField seventname;

    public TextField seventdate;
    public TextField slocation;
    public Label welcomeText;


    ObservableList<event_details> list = FXCollections.observableArrayList();
    @FXML

    protected void onHelloButtonClick() {
        Fetchdata();
    }

    private void Fetchdata() {
        list.clear();

        String jdbcUrl = "jdbc:mysql://localhost:3306/test2b";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM event_details";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {
                int eventid = resultSet.getInt("eventid");
                String eventname = resultSet.getString("eventname");
                String eventdate = resultSet.getString("eventdate");
                String location = resultSet.getString("location");
                eventtable.getItems().add(new event_details(eventid, eventname, eventdate, location));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        eventid.setCellValueFactory(new PropertyValueFactory<event_details,Integer>("eventid"));
        eventname.setCellValueFactory(new PropertyValueFactory<event_details,String>("eventname"));
        eventdate.setCellValueFactory(new PropertyValueFactory<event_details,String>("eventdate"));
        location.setCellValueFactory(new PropertyValueFactory<event_details,String>("location"));
        eventtable.setItems(list);


    }


    public void InsertData(ActionEvent actionEvent) {



        String eventname = seventname.getText();
        String eventdate = seventdate.getText();
        String location = slocation.getText();




        String jdbcUrl = "jdbc:mysql://localhost:3306/test2b";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "INSERT INTO `event_details`( `eventname`, `eventdate`, `location`) VALUES ('"+eventname+"','"+eventdate+"','"+location+"')";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }


    }

    public void UpdateData(ActionEvent actionEvent) {
        String eventid = seventid.getText();
        String eventname = seventname.getText();
        String eventdate = seventdate.getText();
        String location = slocation.getText();




        String jdbcUrl = "jdbc:mysql://localhost:3306/test2b";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "UPDATE `event_details` SET `eventname`='"+eventname+"',`eventdate`='"+eventdate+"',`location`='"+location+"' WHERE sn='"+sn+"' ";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void DeleteData(ActionEvent actionEvent) {

        String eventid = seventid.getText();




        String jdbcUrl = "jdbc:mysql://localhost:3306/test2b";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "DELETE FROM `event_details` WHERE eventid='"+eventid+"'";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void LoadData(ActionEvent actionEvent) {

        String eventid = seventid.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/test2b";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM event_details WHERE eventid='"+eventid+"'";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {

                String eventname = resultSet.getString("eventname");
                String eventdate = resultSet.getString("eventdate");
                String location = resultSet.getString("location");

                seventname.setText(eventname);
                seventdate.setText(eventdate);
                slocation.setText(location);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
