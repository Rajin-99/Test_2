package com.example.test2b;





import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;

public class loginController {


    public TextField usernameField;

    public TextField passwordField;
    public Button lgbutton;




    public Label msg;

    public void loginClick(ActionEvent actionEvent) {
        String useridField= useridField.getText();

        String ipassword= passwordField.getText();
        if (usernameField.isEmpty()&& passwordField.isEmpty()) {
            msg.setText("Provide username or password");
        }
        else{
            String jdbcUrl = "jdbc:mysql://localhost:3306/test2b";
            String dbUser = "root";
            String dbPassword = "";
            try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                    dbPassword)) {
                // Execute a SQL query to retrieve data from the database
                String query = "SELECT * FROM users";
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(query);

                if (resultSet.next()) {
                    try {
                        Parent secondScene = FXMLLoader.load(getClass().getResource("login.fxml"));

                        Stage secondStage = new Stage();

                        secondStage.setTitle("login Scene");

                        secondStage.setScene(new Scene(secondScene));

                        Stage firstSceneStage = (Stage) lgbutton.getScene().getWindow();
                        firstSceneStage.close();

                        secondStage.show();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    msg.setText("Invalid Username or password");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
