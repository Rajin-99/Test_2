package com.example.test2b;


public class users {

    private int useridField;

    private String usernameField;

    private String useremailField;

    private String passwordField;

    public users(int useridField, String usernameField, String useremailField, String passwordField) {
        this. useridField= useridField;
        this.usernameField = usernameField;
        this.useremailField = useremailField;
        this.passwordField = passwordField;

    }

    public int getUseridField() {
        return useridField;
    }

    public void setUseridField(int useridField) {
        this.useridField = useridField;
    }

    public String getUsernameField() {
        return usernameField;
    }

    public void setUsernameField(String usernameField) {
        this.usernameField = usernameField;
    }

    public String getUseremailField() {
        return useremailField;
    }

    public void setUseremailField(String useremailField) {
        this.useremailField = useremailField;
    }

    public String getPasswordField() {
        return passwordField;
    }

    public void setPasswordField(String passwordField) {
        this.passwordField = passwordField;
    }
